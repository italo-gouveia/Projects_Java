package com.pubnub.api.callbacks;

import com.pubnub.api.models.consumer.PNTimeResult;

public abstract class TimeCallback extends PNCallback<PNTimeResult> {
}
