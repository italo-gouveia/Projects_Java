package com.pubnub.api.endpoints.pubsub;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Created by Max on 9/8/16.
 */
@AllArgsConstructor
@Getter
class TestPojo {
    private String field1;
    private String field2;
}
